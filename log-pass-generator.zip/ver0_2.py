import string, random, time

wds=list(string.ascii_lowercase)
nms=list(string.digits)
dn=('да','нет')

while True:
    name_name=input('Введите имя записи:')

    while True:
        logi=input('Сгенерировать логин автоматически? да/нет. ')
        logi=logi.lower()
        if logi not in dn:
            print('Введите "да" или "нет". ')
        else:
            break
    if logi=='да':
        while True:
            log_len=input('Введите длину логина: ')
            if not log_len.isdigit():
                print('Целочисленное значение. Попробуйте снова.')
            else:
                break

        log_len=int(log_len)
        lgn=list()

        i=0

        while i!=log_len:
            dol=random.randint(0,1)
            if dol==0:
                symW_L=random.choice(wds)
                lgn.append(symW_L)
                i=i+1
            else:
                symN_L=random.choice(nms)
                lgn.append(symN_L)
                i=i+1

        i=0

        while i!=len(lgn):
            if lgn[i].isalpha():
                dol=random.randint(0,1)
                if dol==1:
                    lgn[i]=lgn[i].capitalize()
                else:
                    i=i+1
            else:
                 i=i+1
    else:
        lgn=input('Введите логин:')
#print(lgn) #Вывод логина, конец логин блока


    while True:
        psw_b=input('Сгенерировать пароль автоматически? да/нет. ')
        psw_b=psw_b.lower()
        if psw_b not in dn:
            print('Введите "да" или "нет". ')
        else:
            break
    if psw_b=='да':
        while True:
            pas_len=input('Введите длину пароля:')
            if not pas_len.isdigit():
                print('Целочисленное значение. Попробуйте снова.')
            else:
                break
        pas_len=int(pas_len)
        psw=list()
  
        i=0
        while i!=pas_len:
            dol=random.randint(0,1)
            if dol==0:
                symW=random.choice(wds)
                psw.append(symW)
                i=i+1
            else:
                symN=random.choice(nms)
                psw.append(symN)
                i=i+1
           
        i=0
        while i!=len(psw):
            if psw[i].isalpha():
                dol=random.randint(0,1)
                if dol==1:
                    psw[i]=psw[i].capitalize()
                else:
                    i=i+1
            else:
                i=i+1
    else:
        psw=input('Введите пароль: ')

    psw_s=''.join(psw)
    lgn_s=''.join(lgn)
    print('\n','Имя записи: ',name_name,'\n',
          'Логин: ',lgn_s,'\n',
          'Пароль',psw_s,'\n' )


    f=open('pass.txt', 'a')
    f.write('Имя записи: '+name_name+' '+'\n'+
            'Логин: '+lgn_s+' '+'\n'+
            'Пароль: '+psw_s+ ' '+'\n'+
            'Дата создания записи: '+time.ctime()+'\n'+'\n')
    f.close()
